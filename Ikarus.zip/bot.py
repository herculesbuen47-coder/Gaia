import atexit
import os
import random
import re
import subprocess
import sys
from typing import Dict, Optional

from dotenv import load_dotenv
import discord
from discord import app_commands
from discord.ext import commands

from story_data import ATTRIBUTE_LABELS, STORY, determine_final
from storage import create_new_player, get_player, persist_player, load_data, save_data

from pathlib import Path

LOCK_FILE = Path(__file__).parent / ".bot.lock"


def is_process_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}"],
            capture_output=True,
            text=True,
        )
        return str(pid) in result.stdout
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def create_lock_file() -> None:
    if LOCK_FILE.exists():
        try:
            existing_pid = int(LOCK_FILE.read_text().strip())
        except Exception:
            existing_pid = None

        if existing_pid and is_process_running(existing_pid):
            print(f"Outra instância do bot já está rodando (PID {existing_pid}). Saindo.")
            sys.exit(1)
        try:
            LOCK_FILE.unlink()
        except OSError:
            pass

    LOCK_FILE.write_text(str(os.getpid()))


def remove_lock_file() -> None:
    try:
        if LOCK_FILE.exists():
            LOCK_FILE.unlink()
    except OSError:
        pass


atexit.register(remove_lock_file)

load_dotenv(dotenv_path=Path(__file__).parent / ".env")

TOKEN = os.environ.get("DISCORD_TOKEN")
if not TOKEN:
    raise RuntimeError("Defina a variável de ambiente DISCORD_TOKEN antes de executar o bot.")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=["/", "&"], intents=intents)

CHOICE_PATTERN = re.compile(r"^[ABCabc][\.)]?$")
BAR_FILLED = "▓"
BAR_EMPTY = "░"

def parse_choice(content: str) -> Optional[str]:
    cleaned = content.strip().upper()
    if cleaned.endswith(")") or cleaned.endswith("."):
        cleaned = cleaned[:-1].strip()
    if cleaned in {"A", "B", "C"}:
        return cleaned
    return None

INTRO_TEXT = """`╔══════════════════════════════╗`
                          BEM-VINDA
`╚══════════════════════════════╝`

> Antes de começar…
> 
> eu queria te dizer uma coisa.
> 
> Esse jogo foi feito pensando em você.
> 
> De verdade.
> 
> ---
> 
> Eu me inspirei no pouco que te conheço, nos livros que você disse que gosta —
> na forma como as histórias te prendem,
> na maneira como os personagens sentem de verdade,
> e naquele tipo de narrativa que não é só sobre o que acontece…
> 
> mas sobre o que fica.
> 
> ---
> 
> Aqui, você vai acompanhar a vida da Gaia ao longo de três anos.
> 
> As escolhas que você fizer vão moldar quem ela se torna,
> como ela se relaciona com as pessoas
> e até a forma como ela enxerga o mundo.
> 
> ---
> 
> Não existem escolhas certas.
> 
> Só escolhas que levam a caminhos diferentes.
> 
> Algumas vão aproximar.
> 
> Outras vão afastar.
> 
> Algumas vão fazer sentido só depois."""


INTRO_TEXT_2 = """> ---
> 
> O jogo funciona por capítulos.
> 
> Em certos momentos, você vai precisar escolher entre opções (A, B ou C).
> Cada decisão muda a história — mesmo quando isso não for óbvio.
> 
> ---
> 
> Ao longo da jornada, algumas coisas dentro da Gaia vão mudar.
> 
> Você não vai ver isso diretamente o tempo todo,
> mas pode acompanhar usando o comando **/status**.
> 
> Lá você vai encontrar cinco aspectos:
> 
> **:brain: Razão — como ela pensa, analisa e mantém o controle**
> **:heart: Emoção — como ela se conecta, sente e se abre**
> **:hole: Vazio — o quanto ela evita, se afasta ou se fecha**
> **:mag: Investigação — o quanto ela busca respostas e padrões**
> **:crossed_swords: Ação — o quanto ela age sem hesitar**
> 
> ---
> 
> Esses aspectos mudam com suas escolhas.
> 
> E, no final…
> 
> eles ajudam a definir o caminho que a história vai seguir.
> 
> ---
> 
> Mas não se preocupe com isso agora.
> 
> ---
> 
> Só leia.
> 
> Sinta.
> 
> E escolha como você escolheria.
> 
> ---
> 
> Eu realmente espero que você se divirta com isso…
> e que, de alguma forma, essa história te prenda do jeito que os livros que você gosta prendem você.
> 
> ---
> 
> Agora…
> 
> é só começar.
> 
> Digite /continuar"""

STATE_PHRASES = [
    "Entre o que foi… e o que ainda ecoa.",
    "Algo mudou. Você ainda não sabe o quê.",
    "Nem tudo voltou ao lugar certo.",
    "Há algo no ar que você não consegue nomear.",
    "O silêncio tem peso hoje.",
    "Você sente que algo está por vir.",
]

TREND_PHRASES = {
    "razao": "Você está analisando tudo… até o que não deveria.",
    "emocao": "Você ainda sente mais do que entende.",
    "vazio": "Às vezes, não agir parece mais natural do que escolher.",
    "investigacao": "A verdade está próxima… ou você está indo longe demais.",
    "acao": "Você resolve antes de pensar… e isso tem funcionado.",
}

RECENT_PHRASES = [
    "Você hesitou… e isso ainda permanece.",
    "Você escolheu agir sem pensar duas vezes.",
    "Você ignorou algo que talvez fosse importante.",
    "Você percebeu algo que outros não perceberiam.",
    "Você deixou algo te afetar mais do que deveria.",
    "Você decidiu seguir em frente, mesmo com dúvidas.",
]

STRANGE_PHRASES = {
    "razao": "Você tem certeza de que isso aconteceu assim?",
    "emocao": "Você sente isso… ou só quer sentir?",
    "vazio": "Há um vazio que você não consegue preencher.",
    "investigacao": "Você está perto demais da verdade.",
    "acao": "Você agiu. Mas foi sua escolha?",
}


@bot.event
async def on_ready() -> None:
    print(f"Bot conectado como {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"Slash commands sincronizados: {len(synced)}")
    except Exception as exc:
        print("Falha ao sincronizar comandos:", exc)


def get_block(chapter: int, block: int) -> Optional[Dict]:
    return STORY.get(chapter, {}).get(block)


def format_block(block: Dict) -> str:
    text = block["text"]
    if "choices" in block:
        text += "\n\n" + "Escolhas:\n"
        for label, content in block["choices"].items():
            text += f"{label}: {content['text']}\n"
    return text


def update_attributes(attributes: Dict[str, int], points: Dict[str, int]) -> None:
    for key, value in points.items():
        attributes[key] = attributes.get(key, 0) + value


def get_status_text(attributes: Dict[str, int], choices: list) -> str:
    import random
    
    # Get dominant attribute
    if not attributes or sum(attributes.values()) == 0:
        state_phrase = "A jornada ainda não começou… ou mal começou."
    else:
        state_phrase = random.choice(STATE_PHRASES)
    
    # Build bars
    bars_lines = []
    for key, label in ATTRIBUTE_LABELS.items():
        value = min(attributes.get(key, 0), 10)
        filled = BAR_FILLED * value
        empty = BAR_EMPTY * (10 - value)
        
        # Check for strange effects
        is_strange = (key in ["investigacao", "vazio"]) and value >= 7
        value_str = f"({value})" if not is_strange else f"({value}?)"
        
        emoji = {"razao": "🧠", "emocao": "❤️", "vazio": "🕳️", "investigacao": "🔍", "acao": "⚔️"}.get(key, "○")
        bars_lines.append(f"{emoji} {label:15} {filled}{empty} {value_str}")
    
    bars_text = "\n".join(bars_lines)
    
    # Get dominant for trend
    if attributes and sum(attributes.values()) > 0:
        dominant = max(attributes.items(), key=lambda item: item[1])[0]
        is_strange_trend = attributes.get(dominant, 0) >= 7 and dominant in ["investigacao", "vazio"]
        trend_phrase = STRANGE_PHRASES.get(dominant, TREND_PHRASES.get(dominant, "")) if is_strange_trend else TREND_PHRASES.get(dominant, "O caminho ainda se define.")
    else:
        trend_phrase = "A jornada está apenas começando."
    
    # Get recent choice for record
    if choices:
        last_choice = choices[-1]
        record_phrase = random.choice(RECENT_PHRASES)
    else:
        record_phrase = "Nenhuma escolha feita ainda."
    
    return f"""╔══════════════════════════════╗
        ◈ STATUS DE GAIA ◈
╚══════════════════════════════╝

▸ Estado atual:
"{state_phrase}"

━━━━━━━━━━━━━━━━━━━━━━

{bars_text}

━━━━━━━━━━━━━━━━━━━━━━

◈ Tendência atual:
"{trend_phrase}"

━━━━━━━━━━━━━━━━━━━━━━

◈ Registro recente:
"{record_phrase}"

━━━━━━━━━━━━━━━━━━━━━━

Digite /continuar"""


def advance_to_next_block(player_data: Dict[str, any]) -> None:
    chapter = player_data["chapter"]
    block = player_data["block"]
    current = get_block(chapter, block)
    if not current:
        return
    next_value = current.get("next")
    if next_value is None:
        if chapter < 5:
            player_data["chapter"] = chapter + 1
            player_data["block"] = 1
        else:
            player_data["block"] = block
        return
    if isinstance(next_value, (list, tuple)) and len(next_value) == 2:
        player_data["chapter"], player_data["block"] = next_value
    else:
        player_data["block"] = next_value


END_CHAPTER_ORDER = ["investigacao", "vazio", "emocao", "razao", "acao"]
END_CHAPTER_PHRASES = {
    "razao": [
        "Nem tudo precisa ser sentido… desde que possa ser entendido.",
        "Você escolhe manter o controle, mesmo quando algo tenta tirá-lo.",
        "Se há um padrão, você vai encontrar — antes que ele encontre você.",
    ],
    "emocao": [
        "Algumas respostas não estão na lógica… mas em quem você escolhe confiar.",
        "Você sente antes de entender — e, dessa vez, isso importa.",
        "Nem tudo que te puxa é erro. Às vezes… é direção.",
    ],
    "vazio": [
        "Ignorar também é uma escolha… e ela sempre cobra depois.",
        "O silêncio pode esconder… mas nunca apaga.",
        "Você escolhe não olhar — mas algo continua olhando por você.",
    ],
    "investigacao": [
        "Você não deixa perguntas existirem sem resposta.",
        "Se algo começou… você vai até o fim.",
        "Quanto mais você vê, menos consegue parar.",
    ],
    "acao": [
        "Pensar pode esperar. Você já escolheu agir.",
        "Você não precisa entender tudo para começar.",
        "O primeiro passo já foi dado… mesmo sem saber para onde.",
    ],
}

def get_dominant_attribute(attributes: Dict[str, int]) -> str:
    dominant = None
    for attr in END_CHAPTER_ORDER:
        if dominant is None or attributes.get(attr, 0) > attributes.get(dominant, 0):
            dominant = attr
    return dominant or "razao"


def distort_phrase(phrase: str) -> str:
    if phrase.endswith("..."):
        return f"{phrase} certo?"
    if phrase.endswith("."):
        return f"{phrase[:-1]}... certo?"
    return f"{phrase}... certo?"


def get_chapter_end_phrase(attributes: Dict[str, int]) -> str:
    dominant = get_dominant_attribute(attributes)
    phrase = random.choice(END_CHAPTER_PHRASES.get(dominant, []))
    if attributes.get("investigacao", 0) >= 7 or attributes.get("vazio", 0) >= 7:
        phrase = distort_phrase(phrase)
    return phrase


def get_chapter_1_end_text(attributes: Dict[str, int]) -> str:
    phrase = get_chapter_end_phrase(attributes)
    return f"━━━━━━━━━━━━━━━━━━━━━━\n“{phrase}”\n━━━━━━━━━━━━━━━━━━━━━━\n1/5"


def get_final_result(player_data: Dict[str, any]) -> str:
    final = determine_final(player_data["attributes"])
    return f"O final de Gaia é: **{final}**.\n" + (
        "A história conclui que, no fim, cada escolha desenhou o destino que ela merecia."
    )


async def send_current_block(user_id: int, respond_func, player_data: Dict[str, any], should_persist: bool = True) -> None:
    if player_data.get("finished"):
        await respond_func("A jornada de Gaia já terminou. Use /reiniciar para começar de novo.")
        return

    chapter = player_data["chapter"]
    block = player_data["block"]
    current = get_block(chapter, block)
    if not current:
        await send_long_message(respond_func, "A jornada de Gaia já chegou ao fim. Use /reiniciar para começar de novo.")
        player_data["finished"] = True
        player_data["awaiting_choice"] = False
        if should_persist:
            persist_player(user_id, player_data)
        return

    text = f"**Capítulo {chapter} • Bloco {block}**\n\n{current['text']}"
    if "choices" in current:
        text += "\n\nResponda com A, B ou C para seguir."
        player_data["awaiting_choice"] = True
        if should_persist:
            persist_player(user_id, player_data)
        await send_long_message(respond_func, text)
        return

    await send_long_message(respond_func, text)
    if current.get("next") is not None:
        await send_long_message(respond_func, "Use /continuar para seguir a história.")
    if current.get("next") is None:
        if chapter == 5:
            result_text = get_final_result(player_data)
            await send_long_message(respond_func, result_text)
            player_data["finished"] = True
            player_data["awaiting_choice"] = False
            if should_persist:
                persist_player(user_id, player_data)
            return
        if STORY.get(chapter + 1):
            player_data["chapter"] += 1
            player_data["block"] = 1
            player_data["awaiting_choice"] = False
            if should_persist:
                persist_player(user_id, player_data)
            await send_long_message(respond_func, "Capítulo concluído. Use `/continuar` para seguir para o próximo capítulo.")
            return
        await send_long_message(respond_func, "A jornada de Gaia chegou ao fim. Obrigado por jogar!")
        player_data["finished"] = True
        player_data["awaiting_choice"] = False
        if should_persist:
            persist_player(user_id, player_data)
        return

    next_value = current["next"]
    if isinstance(next_value, (list, tuple)) and len(next_value) == 2:
        player_data["chapter"], player_data["block"] = next_value
    else:
        player_data["block"] = next_value
    player_data["awaiting_choice"] = False
    if should_persist:
        persist_player(user_id, player_data)


def textwrap(text: str) -> str:
    return text


MAX_DISCORD_MESSAGE_LENGTH = 2000

def split_message(text: str, limit: int = MAX_DISCORD_MESSAGE_LENGTH) -> list[str]:
    chunks = []
    while text:
        if len(text) <= limit:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, limit)
        if split_at == -1:
            split_at = text.rfind(" ", 0, limit)
        if split_at == -1:
            split_at = limit
        chunks.append(text[:split_at].rstrip())
        text = text[split_at:].lstrip()
    return chunks


async def send_long_message(respond_func, text: str) -> None:
    for chunk in split_message(text):
        await respond_func(chunk)


class InteractionResponder:
    def __init__(self, interaction: discord.Interaction):
        self.interaction = interaction
        self.responded = False

    async def send(self, content: str) -> None:
        if not self.responded:
            await self.interaction.response.send_message(content)
            self.responded = True
        else:
            await self.interaction.followup.send(content)


async def handle_iniciar(send_func, user_id: int, nome: str = None) -> None:
    player_data = get_player(user_id)
    if player_data:
        if player_data.get("finished"):
            await send_func("Sua jornada anterior terminou. Use /reiniciar para começar de novo.")
            return
        await send_func("Você já iniciou a jornada. Use /continuar para seguir de onde parou.")
        return
    if nome and nome.lower() != "gaia":
        await send_func("Eu disse… **Gaia**.")
        return
    await send_func(INTRO_TEXT)
    await send_func(INTRO_TEXT_2)


async def handle_continuar(send_func, user_id: int) -> None:
    player_data = get_player(user_id)
    if player_data and player_data.get("finished"):
        await send_func("A jornada de Gaia já terminou. Use /reiniciar para começar de novo.")
        return
    if not player_data:
        player_data = create_new_player()
        persist_player(user_id, player_data)

    if player_data.get("awaiting_choice"):
        await send_func("Uma escolha está pendente. Responda com A, B ou C para continuar.")
        return
    await send_current_block(user_id, send_func, player_data)


async def handle_status(send_func, user_id: int) -> None:
    player_data = get_player(user_id)
    if not player_data:
        await send_func("Você ainda não iniciou a jornada. Use `/iniciar Gaia` para começar.")
        return
    status_text = get_status_text(player_data["attributes"], player_data["choices"])
    await send_func(status_text)


async def handle_reiniciar(send_func, user_id: int) -> None:
    player_data = get_player(user_id)
    if not player_data:
        await send_func("Você ainda não iniciou nenhuma jornada. Use `/iniciar Gaia` para começar.")
        return
    data = load_data()
    if str(user_id) in data:
        del data[str(user_id)]
        save_data(data)
    await send_func("Sua jornada foi reiniciada. Use `/iniciar Gaia` para começar novamente.")


@bot.command(name="iniciar", description="Começa a jornada de Gaia com Ikarus.")
async def iniciar(ctx, nome: str = None) -> None:
    if ctx.author.bot:
        return
    await handle_iniciar(ctx.send, ctx.author.id, nome)


@bot.tree.command(name="iniciar", description="Começa a jornada de Gaia com Ikarus.")
async def iniciar_slash(interaction: discord.Interaction, nome: Optional[str] = None) -> None:
    if interaction.user.bot:
        return
    responder = InteractionResponder(interaction)
    await handle_iniciar(responder.send, interaction.user.id, nome)


@bot.command(name="continuar", description="Continua a história do ponto onde você parou.")
async def continuar(ctx) -> None:
    if ctx.author.bot:
        return
    await handle_continuar(ctx.send, ctx.author.id)


@bot.tree.command(name="continuar", description="Continua a história do ponto onde você parou.")
async def continuar_slash(interaction: discord.Interaction) -> None:
    if interaction.user.bot:
        return
    responder = InteractionResponder(interaction)
    await handle_continuar(responder.send, interaction.user.id)


@bot.command(name="status", description="Mostra um resumo do seu progresso e tendências.")
async def status(ctx) -> None:
    if ctx.author.bot:
        return
    await handle_status(ctx.send, ctx.author.id)


@bot.tree.command(name="status", description="Mostra um resumo do seu progresso e tendências.")
async def status_slash(interaction: discord.Interaction) -> None:
    if interaction.user.bot:
        return
    responder = InteractionResponder(interaction)
    await handle_status(responder.send, interaction.user.id)


@bot.command(name="reiniciar", description="Reinicia toda a sua jornada do zero.")
async def reiniciar(ctx) -> None:
    if ctx.author.bot:
        return
    await handle_reiniciar(ctx.send, ctx.author.id)


@bot.tree.command(name="reiniciar", description="Reinicia toda a sua jornada do zero.")
async def reiniciar_slash(interaction: discord.Interaction) -> None:
    if interaction.user.bot:
        return
    responder = InteractionResponder(interaction)
    await handle_reiniciar(responder.send, interaction.user.id)


@bot.event
async def on_message(message: discord.Message) -> None:
    print(f"[DEBUG] Mensagem recebida de {message.author}: {message.content}")
    if message.author.bot:
        print("[DEBUG] Ignorando mensagem de bot")
        return
    content = message.content.strip()
    print(f"[DEBUG] Conteúdo: {content}")
    
    # Check for commands first
    if content.startswith("/") or content.startswith("&"):
        print("[DEBUG] É um comando com prefixo / ou &")
        await bot.process_commands(message)
        return
    
    choice = parse_choice(content)
    if not choice:
        print("[DEBUG] Não é uma escolha A/B/C")
        return
    print(f"[DEBUG] É uma escolha A/B/C: {choice}")
    player_data = get_player(message.author.id)
    print(f"[DEBUG] Player data: {player_data}")
    if not player_data or not player_data.get("awaiting_choice"):
        print("[DEBUG] Sem jogo iniciado ou sem escolha pendente")
        return
    chapter = player_data["chapter"]
    block = player_data["block"]
    current = get_block(chapter, block)
    if not current or "choices" not in current:
        return
    selected = current["choices"].get(choice)
    if not selected:
        await message.channel.send("Escolha inválida. Responda apenas A, B ou C.")
        return
    update_attributes(player_data["attributes"], selected["points"])
    player_data["choices"].append({
        "chapter": chapter,
        "block": block,
        "choice": choice,
    })
    player_data["awaiting_choice"] = False
    next_block = selected.get("next", current.get("next"))
    if next_block is not None:
        if isinstance(next_block, (list, tuple)) and len(next_block) == 2:
            if chapter == 1 and next_block[0] == 2:
                await send_long_message(message.channel.send, get_chapter_1_end_text(player_data["attributes"]))
            player_data["chapter"], player_data["block"] = next_block
        else:
            player_data["block"] = next_block
    persist_player(message.author.id, player_data)
    await message.channel.send(f"Você escolheu {choice}. Continuando...")
    await send_current_block(message.author.id, message.channel.send, player_data, should_persist=True)


if __name__ == "__main__":
    create_lock_file()
    try:
        bot.run(TOKEN)
    finally:
        remove_lock_file()
