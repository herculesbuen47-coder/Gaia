from typing import Dict

STORY = {
    1: {
        1: {
            "text": (
                "╔══════════════════════════════╗\n"
                "        CAPÍTULO 1\n"
                "   \"Aquilo que insiste em ser visto\"\n"
                "╚══════════════════════════════╝\n\n"
                "Gaia nunca teve dificuldade com rotina. Na verdade, era exatamente o contrário: ela precisava dela. O despertador tocava sempre no mesmo horário, o quarto permanecia organizado, roupas dobradas com precisão, objetos exatamente onde deveriam estar. Nada fora do padrão. Era assim que funcionava — e era assim que ela funcionava. Porque, quando tudo ao redor se mantém estável, fica mais fácil ignorar o que não está.\n\n"
                "Naquela manhã, não havia nada de diferente. E ainda assim… havia. Gaia abriu os olhos antes do alarme tocar. Não de forma brusca, nem assustada — foi natural demais. Como se algo tivesse despertado ela antes do tempo certo. Ela permaneceu deitada por alguns segundos, olhando para o teto. Não estava pensando, mas também não estava vazia. Era aquela sensação estranha de transição, como estar entre um sonho e a realidade sem saber exatamente em qual dos dois você está.\n\n"
                "O alarme finalmente tocou. Ela desligou sem olhar. O gesto automático. Mas o tempo que ficou parada depois disso… não foi. Gaia se sentou devagar. O quarto estava igual, cada detalhe no lugar, exatamente como deveria. E isso não ajudava. Na verdade, tornava tudo mais evidente. Porque a sensação não vinha de fora — vinha dela.\n\n"
                "Mais tarde, a rotina seguiu. Café sem gosto, movimentos repetidos, pensamentos controlados. A cidade não mudou. A Ordem não mudou. Mas Gaia… percebia mais. Como se algo tivesse sido ajustado em uma frequência que só ela estava ouvindo. Ela caminhava pelo corredor como sempre fazia — passos firmes, olhar direto, sem se distrair. Mas dessa vez, os detalhes não passavam. Uma conversa que parava quando ela se aproximava. Um agente que desviava o olhar rápido demais. Uma porta que demorava meio segundo a mais para fechar. Pequenas coisas. Coisas que não significavam nada. Mas que, juntas, formavam algo.\n\n"
                "Ela parou por um instante na área central. Não por dúvida, mas por reconhecimento. O lugar era o mesmo… mas a sensação não. Foi então que o celular vibrou. Um som simples. Curto. Mas suficiente. Gaia olhou sem pressa, sem urgência — mas com atenção demais para ser casual. A tela estava acesa. Sem nome, sem número. Apenas um arquivo. Ela não tocou imediatamente. Seu olhar ficou preso ali, porque algo naquilo não parecia novo. Parecia… atrasado. Como se já estivesse esperando.\n\n"
                "O nome era curto. Simples. Mas errado. \"Você já viu isso.\"\n\n"
                "O ar ao redor não mudou. Mas a forma como ela respirava… sim. Gaia segurou o celular com mais firmeza. Por um instante, pensou em guardar. Pensou em ignorar. Seguir como sempre fez. Mas algo nela não permitiu. Não dessa vez. Seus dedos se moveram devagar, sem pressa — mas sem hesitação real. Porque, no fundo… ela já tinha decidido.\n\n"
                "Gaia toca o arquivo.\n\n"
                "Digite /continuar"
            ),
            "next": 2,
        },
        2: {
            "text": (
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "O toque acontece — e não há tempo entre ação e resposta. A tela muda imediatamente, sem carregamento, sem transição. Não parece que o arquivo foi aberto… parece que algo foi retomado. Gaia não afasta o olhar. Ela observa, como sempre faz, mas dessa vez não é suficiente. O fundo escuro permanece, sem interface, sem estrutura reconhecível. Não há imagem clara, não há vídeo, não há nada que se encaixe no que deveria ser um arquivo comum. Apenas um ponto de luz no centro da tela. Pequeno. Instável. Vivo o suficiente para não ser ignorado.\n\n"
                "Gaia aperta levemente o celular. Seu olhar não vacila. O ponto se expande lentamente, não rápido, não agressivo — inevitável. Linhas começam a surgir ao redor, formas incompletas, como fragmentos de algo que ainda está sendo montado. E então, palavras. Não aparecem de uma vez. Elas se constroem, como se estivessem sendo escritas naquele instante.\n\n"
                "“Você demorou.”\n\n"
                "Gaia não reage de imediato, mas o corpo dela sim. Uma leve tensão nos ombros, um ajuste involuntário na respiração. Aquilo não faz sentido. Ela acabou de abrir. Não houve atraso, não houve espera — e ainda assim, a sensação é clara. Aquilo não está respondendo ao agora. Está respondendo a algo que já aconteceu.\n\n"
                "A tela pisca por um segundo — talvez menos. Mas é o suficiente. Porque nesse instante, Gaia vê algo além das palavras. Não completamente, não de forma nítida, mas o bastante para reconhecer. Um formato. Um símbolo. Um olho. Incompleto. Como se estivesse sendo desenhado… ou lembrado.\n\n"
                "A imagem estabiliza novamente. As palavras continuam ali, mas agora há mais. Abaixo da frase, outra linha começa a surgir. Mais lenta. Mais pesada. Como se hesitasse em existir.\n\n"
                "“Você ainda está—”\n\n"
                "A frase para. Não se completa. Não desaparece. Fica. Suspensa. Como algo interrompido no meio.\n\n"
                "Gaia inclina levemente a cabeça, o olhar mais atento agora. Mais envolvido. Ela não desvia, mas pensa. Porque agora não é só sobre o que está ali… é sobre o que falta.\n\n"
                "Digite /continuar"
            ),
            "next": 3,
        },
        3: {
            "text": (
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia continua olhando para a tela. A frase incompleta não desaparece. “Você ainda está—” permanece ali, como se não estivesse quebrada… apenas esperando. Não uma ação imediata, não um toque impulsivo — mas uma decisão. O símbolo continua presente, o olho incompleto, imperfeito demais para ser ignorado e preciso demais para ser coincidência.\n\n"
                "A respiração dela se estabiliza. Mais lenta. Mais consciente. Como se cada pequeno movimento precisasse agora ser escolhido, e não apenas acontecer. Ela não está mais reagindo. Está participando.\n\n"
                "A tela pisca novamente, mas dessa vez não falha. Ela se ajusta. A frase se completa.\n\n"
                "“Você ainda está aqui.”\n\n"
                "Não é uma pergunta. Não pede confirmação. É uma constatação.\n\n"
                "Algo reconheceu ela.\n\n"
                "O peso no ambiente muda. Não visivelmente, não de forma que pudesse ser explicada — mas presente o suficiente para ser sentido. Gaia aperta levemente o celular, sem perceber.\n\n"
                "Abaixo da frase, novas palavras surgem. Mais rápidas agora. Mais diretas.\n\n"
                "“Então escolha.”\n\n"
                "Não há botões. Não há interface. Mas há intenção.\n\n"
                "E ela entende.\n\n"
                "Isso não é passivo. Isso exige algo dela.\n\n"
                "Três possibilidades se formam na tela. Não como opções comuns, mas como caminhos.\n\n"
                "❖ O que Gaia faz?\n\n"
                "A) Responder — “Quem está aí?” (tentar entender o que está respondendo)\n\n"
                "B) Encerrar — desligar o celular imediatamente (interromper antes que avance)\n\n"
                "C) Observar — não responder, apenas continuar olhando (ver até onde isso vai sem interferir)\n\n"
                "Digite A, B ou C"
            ),
            "choices": {
                "A": {
                    "text": "Responder — “Quem está aí?” (tentar entender o que está respondendo)",
                    "points": {"investigacao": 2, "emocao": 1},
                    "next": 4,
                },
                "B": {
                    "text": "Encerrar — desligar o celular imediatamente (interromper antes que avance)",
                    "points": {"acao": 2, "vazio": 1},
                    "next": 5,
                },
                "C": {
                    "text": "Observar — não responder, apenas continuar olhando (ver até onde isso vai sem interferir)",
                    "points": {"razao": 2, "investigacao": 1},
                    "next": 6,
                },
            },
            "next": None,
        },
        4: {
            "text": (
                "📖✨ CAPÍTULO 1 — BLOCO 4A\n"
                "“Aquilo que responde de volta”\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia não hesita dessa vez. Seus dedos se movem com precisão, mais firmes do que ela esperava. “Quem está aí?” A mensagem não é digitada — não há teclado, não há campo de texto — mas, ainda assim, ela acontece. Como se a intenção fosse suficiente.\n\n"
                "Por um instante, nada muda. A tela permanece escura, as palavras imóveis. O símbolo continua ali, incompleto, observando sem realmente estar inteiro. Então, a resposta vem. Não surge de uma vez. Ela se forma. Letra por letra. Como se estivesse sendo escrita no mesmo ritmo em que algo pensa.\n\n"
                "“Você já sabe.”\n\n"
                "Gaia sente um leve aperto no peito. Não forte o suficiente para ser medo, mas presente o bastante para não ser ignorado. Ela não lembra. E, ao mesmo tempo… lembra.\n\n"
                "A tela pisca novamente, mais rápido dessa vez. O símbolo se ajusta. Não muda completamente, mas se aproxima de algo mais definido. O olho agora parece… direcionado. Não apenas um desenho. Um foco.\n\n"
                "“Você demorou.”\n\n"
                "A frase se repete. Igual. Mas diferente.\n\n"
                "Agora não soa como erro.\n\n"
                "Soa como cobrança.\n\n"
                "Gaia não desvia o olhar. Mas, pela primeira vez, ela sente que não está apenas observando algo.\n\n"
                "Ela está sendo observada de volta."
            ),
            "next": 7,
        },
        5: {
            "text": (
                "📖✨ CAPÍTULO 1 — BLOCO 4B\n"
                "“Aquilo que não se encerra”\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia reage rápido. Rápido demais para permitir qualquer dúvida crescer. Seus dedos pressionam o botão lateral com força suficiente para encerrar aquilo antes que avance. A tela apaga.\n\n"
                "Escuro.\n\n"
                "Silêncio.\n\n"
                "Por um segundo, tudo volta ao normal. Ou parece voltar.\n\n"
                "Ela solta o ar devagar, sem perceber que estava segurando. O ambiente ao redor continua o mesmo, os sons da Ordem seguem distantes, controlados, previsíveis.\n\n"
                "Então o celular vibra novamente.\n\n"
                "Uma vez.\n\n"
                "Gaia não olha.\n\n"
                "Outra vez.\n\n"
                "Agora mais forte.\n\n"
                "Ela olha.\n\n"
                "A tela acende sozinha.\n\n"
                "Sem toque. Sem comando.\n\n"
                "O arquivo continua aberto.\n\n"
                "Exatamente como antes.\n\n"
                "As mesmas palavras.\n\n"
                "O mesmo símbolo.\n\n"
                "Como se nada tivesse sido interrompido.\n\n"
                "Como se nada pudesse ser.\n\n"
                "“Você ainda está aqui.”\n\n"
                "Não há erro. Não há falha.\n\n"
                "Há… persistência.\n\n"
                "Gaia percebe, lentamente, que desligar não foi uma escolha que aquilo considerou válida."
            ),
            "next": 7,
        },
        6: {
            "text": (
                "📖✨ CAPÍTULO 1 — BLOCO 4C\n"
                "“Aquilo que se revela quando você não interfere”\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia não se move. Nenhuma resposta, nenhum gesto, nenhum impulso de interromper. Ela apenas observa. Como sempre fez. Como aprendeu a fazer.\n\n"
                "O tempo passa. Ou parece passar.\n\n"
                "A tela permanece ativa, mas não estática. Pequenos ajustes acontecem. Detalhes quase invisíveis. O símbolo se desloca levemente, como se estivesse sendo observado de diferentes ângulos ao mesmo tempo.\n\n"
                "A frase continua ali.\n\n"
                "“Você ainda está aqui.”\n\n"
                "Sem mudança.\n\n"
                "Sem pressão.\n\n"
                "Mas também sem desaparecer.\n\n"
                "Então, lentamente, algo novo acontece.\n\n"
                "Não nas palavras.\n\n"
                "Mas na forma.\n\n"
                "O símbolo se altera.\n\n"
                "Não de maneira clara, não o suficiente para ser apontado com certeza — mas o bastante para ser sentido. Como se estivesse… respondendo à ausência de resposta.\n\n"
                "Gaia inclina levemente a cabeça.\n\n"
                "E, nesse instante—\n\n"
                "a tela reage.\n\n"
                "“Você percebeu.”\n\n"
                "A frase surge sem aviso. Direta. Limpa. Definitiva.\n\n"
                "Não é sobre ação.\n\n"
                "É sobre atenção.\n\n"
                "E, pela primeira vez, Gaia entende que não importa o que ela faça… aquilo não está esperando resposta.\n\n"
                "Está avaliando presença."
            ),
            "next": 7,
        },
        7: {
            "text": (
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia não se levanta imediatamente. O corpo permanece parado, mas a mente já não está mais naquele lugar. O celular continua sobre a mesa, silencioso demais para parecer inofensivo. Ela poderia simplesmente voltar ao relatório. Poderia fingir que aquilo foi só mais uma anomalia isolada. A Ordem estava cheia delas. Sempre esteve.\n\n"
                "Mas não era isso.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Dessa vez… não era.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Ela passa a mão pelo rosto, apoiando o cotovelo na mesa por um instante. O gesto é simples, quase imperceptível, mas carrega mais peso do que deveria. Porque agora ela não está decidindo o que fazer com um caso.\n\n"
                "Está decidindo o que fazer com algo que envolve ela.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Os olhos dela se movem pelo ambiente novamente.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Jaser está mais distante, encostado em uma das colunas laterais. Como sempre, parece não fazer parte do centro das coisas, mas também não está fora delas. Ele observa. Não diretamente. Não de forma óbvia. Mas observa.\n\n"
                "Por um segundo, os olhares se cruzam.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Não há reação.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Mas há entendimento.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Como se ele percebesse que algo saiu do lugar… mesmo sem saber exatamente o quê.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia desvia primeiro.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Sol está em outra área, cercado por telas. Informações abertas, padrões sendo montados, dados cruzando em uma velocidade que a maioria das pessoas ali não acompanharia. Ele não olha para ela. Não ainda.\n\n"
                "Mas Gaia sabe.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Se algo realmente saiu do padrão…\n\n"
                "Sol já está perto de perceber.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "E então—\n\n"
                "Ikarus.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Ele está sentado alguns metros à frente, levemente inclinado sobre um caderno. Não um terminal, não um relatório oficial. Um caderno. Ele escreve devagar, como se cada palavra precisasse existir antes de ser registrada. Não parece distraído. Também não parece focado no ambiente.\n\n"
                "Parece… fora do fluxo.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia observa por alguns segundos.\n\n"
                "Mais do que deveria.\n\n"
                "E algo nela se incomoda com isso.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Porque, de todos ali…\n\n"
                "ele é o único que não parece reagir ao que está acontecendo.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Ou talvez—\n\n"
                "seja o único que já sabe.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia se ajeita na cadeira.\n\n"
                "A decisão começa a se formar.\n\n"
                "Não completamente.\n\n"
                "Mas o suficiente.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Ela não pode ignorar.\n\n"
                "Isso já está claro.\n\n"
                "A questão não é mais *se* ela vai agir.\n\n"
                "É *como*.\n\n"
                "E, principalmente—\n\n"
                "*com quem.*\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "O celular permanece ali.\n\n"
                "Quieto.\n\n"
                "Mas agora—\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "isso não significa segurança.\n\n"
                "Significa espera.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Gaia respira fundo.\n\n"
                "E, pela primeira vez desde que abriu o arquivo…\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "ela percebe.\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "Isso não é sobre entender o que aconteceu.\n\n"
                "É sobre decidir em quem confiar.\n\n"
                "A história termina aqui."
            ),
            "next": None,
        },
    },
}

ATTRIBUTE_LABELS = {
    "razao": "Razão",
    "emocao": "Emoção",
    "vazio": "Vazio",
    "investigacao": "Investigação",
    "acao": "Ação",
}


def determine_final(attributes: Dict[str, int]) -> str:
    """Determine the final based on dominant attribute."""
    if not attributes:
        return "Indefinido"
    
    dominant = max(attributes.items(), key=lambda x: x[1])
    finals = {
        "razao": "O Observador",
        "emocao": "O Conectado",
        "vazio": "O Liberto",
        "investigacao": "O Investigador",
        "acao": "O Agente",
    }
    return finals.get(dominant[0], "Indefinido")